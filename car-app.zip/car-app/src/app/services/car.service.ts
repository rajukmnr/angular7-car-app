import { Injectable } from '@angular/core';
import { Car } from '../models/car';

import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class CarService {
private cars:Car[];

  constructor(private http:HttpClient) {

  }

  getCars():Observable<any>{
return this.http.get('http://localhost:3000/cars');
  }


  getCarById(carId:number){
    return this.http.get(`http://localhost:3000/cars/${carId}`);
  }
  addCar(car:Car):Observable<any>{
 return this.http.post('http://localhost:3000/cars', car);
  }
  deletCar(carId:number){
return this.http.delete('http://localhost:3000/cars/'+ carId);
  }

  editCar(car:Car){
return this.http.put(`http://localhost:3000/cars/${car.id}`,car)
  }
}
